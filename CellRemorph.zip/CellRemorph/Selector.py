# -*- coding: utf-8 -*-
"""
Description: Saves a selected segment of a point cloud (.dat) or mesh
(.obj) as a point cloud and/or a mesh.

Blender version: 3.4.1

@author: Laura Keto
"""

import os
import os.path
from operator import itemgetter
from os import path

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Vector

from .General import (clear_scene, create_obj, dim_value, export_item,
                      init_scene, max_3d_view, obj_import, position_obj,
                      remove_collections, save_output, select_obj)


def get_coords(sel):
    """Returns the point cloud (obj) coordinates (float tuple list)."""

    # Get the point cloud coordinates
    coord_list = [(sel.matrix_world @ v.co) for v in sel.data.vertices]

    # Save the coordinates as floating value tuples into a list
    coords = []
    for v in coord_list:
        coord = (float(v[0]), float(v[1]), float(v[2]))
        coords.append(coord)

    return coords


def save_selection(file_path):
    """
    Saves a selected segment of a mesh or point cloud into the given
    directory as a mesh or point cloud, respectively. If the selection
    is saved as a mesh, the volume and surface area are calculated and
    saved into an output-file.

    Param dir_path: (str) Path to the directory.
    """

    # Get the object type from the extension
    if file_path.endswith('.obj'):
        obj_type = "mesh"
    else:
        obj_type = "point cloud"

    end_msg = f"""Import the {obj_type} and select a part of it before
              saving the selection."""

    # Change to the object mode
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except:
        print("No object selected.")
        return end_msg

    # Calculate the number of verts both in the whole and the selection
    verts = bpy.context.active_object.data.vertices
    selected_verts = [v for v in verts if v.select]
    bpy.ops.object.mode_set(mode='EDIT')

    # Check if none or all vertices selected
    if len(selected_verts) == 0 or len(selected_verts) == len(verts):
        return end_msg

    # Separate the selected part
    bpy.ops.mesh.separate(type='SELECTED')

    # Select only the separated segment and make it active
    bpy.ops.object.mode_set(mode='OBJECT')
    selection = [obj for obj in bpy.context.selected_objects
                 if obj != bpy.context.object]
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = selection[0]
    selection[0].select_set(state=True)
    selection = bpy.context.active_object

    # Define path to the file directory and the name of the segment
    dir_path = os.path.dirname(file_path)
    file_name = os.path.basename(file_path)
    file_name = os.path.splitext(file_name)[0]

    if obj_type == "mesh":
        # Calculate surface area and volume
        sa = dim_value("sa")
        v = dim_value("v")
    else:
        # Get the point location coordinates
        coords = get_coords(selection)
        sa = v = "N/A"

    # Export the segment
    if obj_type == "mesh":
        # Export segment selected from a mesh as a mesh
        item_name = file_name + "_mesh"
        export_item(dir_path, item_name, 1, "selections", ".obj")
    else:
        # Export segment selected from a point cloud as a point cloud
        item_name = file_name + "_ptcloud"
        export_item(dir_path, item_name, 1, "selections", ".dat", coords)

    # Define a path to the output-file
    output_path = os.path.join(dir_path, file_name + "_selections_output.dat")

    # Define a number for the segment based on the output-file
    if not path.exists(output_path):
        # Numbering starts from one if no output-file exist
        sel_number = 1
    else:
        # Consecutive segments are numbered based on the info on output
        sel_number = sum(1 for line in open(output_path))

    # Rename the segment
    obj = bpy.data.collections[0].objects[-1]
    obj.name = "Selection_" + str(sel_number)

    # Save the parameters into the existing or a new output-file
    final_output = False
    output_values = np.array([str(sel_number), str(v), str(sa)])
    labels = np.array(["Selection", "Volume", "Surface Area"])
    save_output(dir_path, output_values, labels, final_output, file_name +
                "_selections")

    # Initialize the scene
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = bpy.data.collections[0].objects[0]
    bpy.data.collections[0].objects[0].select_set(state=True)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')

    end_msg = "Selection successful"
    return end_msg
