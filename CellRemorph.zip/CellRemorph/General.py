# -*- coding: utf-8 -*-
"""
Description: Functions for removing collections, initializing and
clearing the scene, selecting and positioning an object, cleaning an
object, exporting an item, saving the output, calculating surface area
or volume, and maximizing the 3d view.

Blender version: 3.4.1

@author: Laura Keto
"""

import os
import os.path
import time
from os import path
from pathlib import Path

import bmesh
import bpy
import numpy as np


def remesher(oct_depth, scale):
    """Remeshes the object with specified octree depth and scale."""

    # Save the original mode and go to object mode
    original_mode = bpy.context.object.mode
    bpy.ops.object.mode_set(mode='OBJECT')

    # Select the object
    active_obj = bpy.context.active_object
    active_obj.select_set(state=True)

    # Remesh the object
    if len(active_obj.modifiers) == 0:
        rm = active_obj.modifiers.new("Remesh", type='REMESH')
        rm.mode = 'SMOOTH'
        rm.octree_depth = oct_depth
        rm.scale = scale
        rm.use_remove_disconnected = False
    # If already remesh modifier applied, change only the octree depth
    else:
        rm = active_obj.modifiers[0]
        rm.octree_depth = oct_depth
        rm.scale = scale

    # Switch to the original more
    bpy.ops.object.mode_set(mode=original_mode)

    if bpy.context.object.mode == "EDIT":
        bpy.ops.mesh.select_all(action='SELECT')


def remove_collections(collections):
    """Removes each collection in a list and all the objects within."""
    for collection in collections:
        for obj in collection.objects:
            bpy.data.objects.remove(obj)
        bpy.data.collections.remove(collection)


def init_scene():
    """Initializes the scene."""
    # Remove all the collections and the objects within them
    remove_collections(bpy.data.collections)

    # Create a new collection and add it under scene collection
    coll = bpy.data.collections.new('Collection')
    bpy.context.scene.collection.children.link(coll)

    # Make the newly created collection active
    lc = bpy.context.view_layer.layer_collection.children[coll.name]
    bpy.context.view_layer.active_layer_collection = lc

    # Add an object to the scene
    bpy.ops.mesh.primitive_cube_add()


def clear_scene():
    """Clears the scene."""
    # Switch scene to object mode if in edit mode
    if bpy.context.object.mode == 'EDIT':
        bpy.ops.object.mode_set(mode='OBJECT')

    # Select everything in the scene and delete
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)


def create_obj(vertices, edges=None, faces=None):
    """Returns an object created from vertices (and edges and faces)."""

    # Define empty lists for edges and faces if needed
    if edges == None:
        edges = []
    if faces == None:
        faces = []

    # Create a mesh
    m = bpy.data.meshes.new('mesh')
    m.from_pydata(vertices, edges, faces)
    m.update()

    # Create an object from the mesh
    obj = bpy.data.objects.new('obj', m)

    return obj


def obj_import(file_path, mode=""):
    """Imports a point cloud (dat) or mesh (obj) as an object."""

    # Initialize and clear the scene
    init_scene()
    clear_scene()

    # Remove first collection
    for obj in bpy.data.collections[0].objects:
        bpy.data.objects.remove(obj)
    bpy.data.collections.remove(bpy.data.collections[0])

    # Import either a point cloud (dat) or mesh (obj)
    if file_path.endswith('.dat'):

        # Read the dat-file point cloud coordinates into a nested list
        all_coords = []
        with open(file_path, 'r') as read_obj:
            for line in read_obj:
                try:
                    coord_list = line.split()

                    # Check if the line consists of three values
                    if len(coord_list) != 3:
                        return False

                    # Remove the possible "," from the line end
                    if coord_list[2].endswith(","):
                        coord_list[2] = coord_list[2][:-1]

                    all_coords.append(coord_list)
                except:
                    print("The file is in wrong format.")
                    return False

        # Transform the coordinates into floating point numbers
        coords = []
        for v in all_coords:
            try:
                coord = (float(v[0]), float(v[1]), float(v[2]))
                coords.append(coord)
            except:
                print("The file is in wrong format.")
                return False

        # Create an object with only the coordinates
        obj = create_obj(coords)

        # Get the object name and rename it
        obj_name = Path(file_path).stem
        obj.name = obj_name

        # Create a new collection and save the object into it
        collection = bpy.data.collections.new('Collection')
        bpy.context.scene.collection.children.link(collection)
        collection.objects.link(obj)

    else:
        # Import the mesh
        bpy.ops.import_scene.obj(filepath=file_path)

        # Select the mesh and rename it
        obj = select_obj()

        # Get the object name and rename it
        obj_name = Path(file_path).stem
        obj.name = obj_name

        # Create a new collection and save the object into it
        collection = bpy.data.collections.new('Collection')
        bpy.context.scene.collection.children.link(collection)
        collection.objects.link(obj)

        # Unlink the mesh from the scene collection
        bpy.context.scene.collection.objects.unlink(obj)

    # Select and position the object
    bpy.context.view_layer.objects.active = bpy.context.scene.objects[0] # !!! view_layer -> scene
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
    position_obj()

    # Apply the object's rotation to its data
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

    if mode == "edit":
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')

    # Maximize the 3d view in order to display the object correctly
    max_3d_view()

    return True


def select_obj():
    """Selects and returns the first object in the scene collection."""
    obj = bpy.context.view_layer.objects[0]
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj
    obj.select_set(state=True)
    return obj


def position_obj():
    """Positions the object origin and the object in the center."""
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
    previous_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.view3d.snap_cursor_to_center()
    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
    bpy.context.area.type = previous_context


def clean_obj():
    """Removes disconnected segments from a mesh (obj)."""

    # Save the original mode and go to object mode
    original_mode = bpy.context.object.mode
    bpy.ops.object.mode_set(mode='OBJECT')

    # Make the first object in the scene collection active
    obj = select_obj()

    # Get the object mesh
    mesh = obj.data

    # Create a dictionary with keys to each vertex index
    paths = {v.index:set() for v in mesh.vertices}

    # Link keys to connected vertices through edges
    for edge in mesh.edges:
        paths[edge.vertices[0]].add(edge.vertices[1])
        paths[edge.vertices[1]].add(edge.vertices[0])

    # Find the disconnected segments
    dis_segs = []
    while True:
        try:
            i = next(iter(paths.keys()))
        except StopIteration:
            break

        # Define the starting indexes
        dis_seg = {i}
        current = {i}

        while True:
            # Get indexes
            indexes = {ind for ind in current if ind in paths}
            if not indexes:
                break

            # Get the new links
            current = {v_edge for ind in indexes for v_edge in paths[ind]}
            dis_seg.update(current)

            # Remove the previous
            for key in indexes: paths.pop(key)

        dis_segs.append(dis_seg)

    # Find the largest part of the mesh
    idx = dis_segs.index(max(dis_segs, key=len))
    largest_part = dis_segs[idx]
    obj = bpy.context.active_object

    # Switch to edit mode to deselect each vertex
    bpy.ops.object.mode_set(mode='EDIT') 
    bpy.ops.mesh.select_mode(type="VERT")
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')

    # Select the largest part of the mesh
    for v in largest_part:
        obj.data.vertices[v].select = True

    # Inverse the selection to select all the disconnected mesh parts
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='INVERT')
    obj = bpy.context.object

    # Get the bmesh
    bm = bmesh.from_edit_mesh(obj.data)

    # Remove the disconnected mesh parts
    for v in bm.verts:
        if v.select:
            bm.verts.remove(v)

    # Switch to the original more
    bpy.ops.object.mode_set(mode=original_mode)

    if bpy.context.object.mode == "EDIT":
        bpy.ops.mesh.select_all(action='SELECT')


def export_item(dir_path, item_name, item_num, tag, type, coords=[(0.0,0.0)]):
    """
    Export an item into a subdirectory (for the first item creates a
    new folder and consecutive items saves into the same folder).

    Param dir_path: (str) The original directory path.
    Param item_name: (str) The item name.
    Param item_num: (int) The item number.
    Param tag: (str) Name for the subdirectory and the items.
    Param type: (str) Item type (.obj/.dat).
    Param coords: (float tuple list) The point cloud coordinates.
    Return exp_dir_path: (str) The item subdirectory path.
    Return exp_obj_path: (str) The item path.
    """

    # Define the subdirectory name
    exp_dir = item_name + "_" + tag

    # Define the subdirectory path under the original directory
    exp_dir_path = os.path.join(dir_path, exp_dir)

    # Create the subdirectory if it does not already exist
    if not os.path.exists(exp_dir_path):
        os.mkdir(exp_dir_path)

    # Define the name of the exported object
    exp_obj = item_name + "_" + tag + "_" + str(item_num) + type

    # Define the path to the exported object under the subdirectory
    exp_obj_path = os.path.join(exp_dir_path, exp_obj)

    # If the path exists, update it until unused number is reached
    while os.path.exists(exp_obj_path):
        item_num += 1
        exp_obj = item_name + "_" + tag + "_" + str(item_num) + type
        exp_obj_path = os.path.join(exp_dir_path, exp_obj)

    # Export either an object or dat-file
    if type == ".obj":
        bpy.ops.export_scene.obj(filepath=exp_obj_path, use_materials=False,
                                 use_selection=True)
    elif type == ".dat":
        np.savetxt(exp_obj_path, coords, delimiter=" ", fmt='%s')

    return exp_dir_path, exp_obj_path


def save_output(dir_path, output_values, labels, final_output, file_name=""):
    """
    Save the output values into an output file.

    Param dir_path: (str) The directory path.
    Param output_values: (ndarray) The output values.
    Param labels: (ndarray) Labels for the output values.
    Param final_output: (bool) The last output line to be saved.
    """

    # If the file name is specified, add it to the output file name
    if file_name != "":
        output_path = os.path.join(dir_path, file_name + "_output.dat")
    else:
        output_path = os.path.join(dir_path, "output.dat")

    # If the output-file does not exist, create it
    if not path.exists(output_path) and not final_output:
        np.savetxt(output_path, labels.reshape(1, labels.shape[0]),
                   delimiter=", ", fmt='%s')

    # Open the output-file temporarily and save the values into it
    f=open(output_path, 'ab')
    np.savetxt(f, output_values.reshape(1, output_values.shape[0]),
               delimiter=", ", fmt='%s')
    f.close()


def dim_value(dim_type):
    """
    Returns the dimensional value of an object (surface area or
    volume).

    Param dim_type: (str) The dimension (sa or v) to be calculated.
    Return dim: (float) The dimensional value.
    """

    bpy.ops.object.mode_set(mode='OBJECT')

    # Center the object before calculation
    bpy.context.object.location = (0,0,0)

    # Calculations require the object to be in bmesh format
    bm = bmesh.new()
    bm.from_object(bpy.context.object, bpy.context.view_layer.depsgraph)

    # Calculate either the volume or surface area
    if dim_type == "sa":
        dim = float(sum(f.calc_area() for f in bm.faces))
    elif dim_type == "v":
        dim = float(bm.calc_volume(signed=True))

    return dim


def max_3d_view():
    """Maximizes the 3d view in all windows."""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for region in area.regions:
                if region.type == 'WINDOW':
                    override = {'area': area, 'region': region}
                    bpy.ops.view3d.view_all(override)
