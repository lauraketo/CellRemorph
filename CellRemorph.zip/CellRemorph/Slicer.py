# -*- coding: utf-8 -*-
"""
Description: Slices a mesh into desired number of segments equal either
in surface area or volume, along any of the coordinate axes.

Blender version: 3.4.1

@author: Laura Keto
"""

import os
import os.path
import shutil
import statistics
import time
from mathutils import Euler
from os import path
from pathlib import Path

import bmesh
import bpy
import numpy as np

from .General import (clear_scene, dim_value, export_item, init_scene,
                      max_3d_view, position_obj, remove_collections,
                      save_output, select_obj)


def bisector(edit_coll, rem_obj, axis, side, intersect, dim_type):
    """
    Bisects the object along the intersect.
    
    Param edit_coll: (collection) Edited segments.
    Param rem_obj: (object) The remainder object.
    Param axis: (str) The axis along which the object is cut.
    Param side: (str) The side of the object to be preserved.
    Param intersect: (float) The object cut location.
    Param dim_type: (str) The dimension (SA or V) to be calculated.
    Return edit_obj: (object) The edited object.
    """

    # Remove every object in edit_coll
    for obj in edit_coll.objects:
        bpy.data.objects.remove(obj)

    # Copy rem_obj to edit_coll and select only it
    edit_obj = rem_obj.copy()
    edit_obj.data = edit_obj.data.copy()
    edit_coll.objects.link(edit_obj)
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = edit_obj
    edit_obj.select_set(state=True)

    # Change to edit mode and select the whole object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')

    # Bisect the object along one of the axes
    if axis == "x":

        # Bisect the object along the intersect, save one side
        if side == "outer":
            bpy.ops.mesh.bisect(plane_co=(intersect, 0, 0),
                                plane_no=(1, 0, 0), clear_inner=True,
                                clear_outer=False)
        elif side == "inner":
            bpy.ops.mesh.bisect(plane_co=(intersect, 0, 0),
                                plane_no=(1, 0, 0), clear_inner=False,
                                clear_outer=True)
    elif axis == "y":

        # Bisect the object along the intersect, save one side
        if side == "outer":
            bpy.ops.mesh.bisect(plane_co=(0, intersect, 0),
                                plane_no=(0, 1, 0), clear_inner=True,
                                clear_outer=False)
        elif side == "inner":
            bpy.ops.mesh.bisect(plane_co=(0, intersect, 0),
                                plane_no=(0, 1, 0), clear_inner=False,
                                clear_outer=True)
    elif axis == "z":

        # Bisect the object along the intersect, save one side
        if side == "outer":
            bpy.ops.mesh.bisect(plane_co=(0, 0, intersect),
                                plane_no=(0, 0, 1), clear_inner=True,
                                clear_outer=False)
        elif side == "inner":
            bpy.ops.mesh.bisect(plane_co=(0, 0, intersect),
                                plane_no=(0, 0, 1), clear_inner=False,
                                clear_outer=True)

    # Select the obtained side of the object
    bpy.ops.mesh.select_all(action='SELECT')

    # If slicing by volume, fill the cut surface
    if dim_type == "v":
        bpy.ops.mesh.fill_holes(sides=0)

    return edit_obj


def find_intersect(dir_path, edit_coll, rem_obj, axis, avg_dim, dim, checkers,
                   intersect, em, step, dim_type, seg_n):
    """
    Finds the intersection that divides the object into segments of
    equal dimensions.

    Param dir_path: (str) The object directory path.
    Param edit_coll: (collection) Edited segments.
    Param rem_obj: (str) The remainder object.
    Param axis: (str) The axis along which the object is cut.
    Param avg_dim: (float) The average dimensional value of object seg.
    Param dim: (float) The dimensional value of object segment.
    Param checkers: (bool list) The dimension within the error margin.
    Param intersect: (float) The object cut location.
    Param em: (float) The error margin.
    Param step: (float) The adjustation to the cut location.
    Param dim_type: (str) The dimension (SA or V) to be calculated.
    Return dim: (float) The dimensional value of object segment.
    Return intersect: (float) The new object cut location.
    """

    # Check if the dimensional value has started to oscillate
    if checkers[0] and checkers[1]:

        # Reduce the step size
        step = step/10

        # Reset the checkers
        checkers[0] = False
        checkers[1] = False

    # Hitting the error margin finalizes the bisector
    if abs(dim - avg_dim) <= em:
        return dim, intersect

    # Undershoot indicates that target value is not yet reached
    elif (dim - avg_dim) > em:

        # The 1st checker value keeps track of undershooting
        checkers[0] = True

        # Define a new larger value for the intersect
        intersect += step

        # Bisect the mesh along the new intersect
        edit_obj = bisector(edit_coll, rem_obj, axis, "outer", intersect,
                            dim_type)

        # Calculate the dimensional value (SA or V)
        dim = dim_value(dim_type)

        # Find out if the new intersect value falls on the target
        dim, intersect = find_intersect(dir_path, edit_coll, rem_obj, axis,
                                        avg_dim, dim, checkers, intersect, em,
                                        step, dim_type, seg_n)

    # Overshoot indicates that target value is exceeded
    elif (dim - avg_dim) < em:

        # The 2nd checker value keeps track of overshooting
        checkers[1] = True

        # Define a new smaller value for the intersect
        intersect -= step

        # Bisect the mesh along the new intersect
        edit_obj = bisector(edit_coll, rem_obj, axis, "outer", intersect,
                            dim_type)

        # Calculate the dimensional value (SA or V)
        dim = dim_value(dim_type)

        # Find out if the new intersect value falls on the target
        dim, intersect = find_intersect(dir_path, edit_coll, rem_obj, axis,
                                        avg_dim, dim, checkers, intersect, em,
                                        step, dim_type, seg_n)

    return dim, intersect


def sectioner(dir_path, obj_path, orig_coll, edit_coll, rem_coll, rem_obj,
              obj_name, n_segs, axis, avg_dim, dims, intersects, step, em,
              dim_type):
    """ 
    Iterates through the list of divisions to be performed for each
    coordinate axis x, y, and z. Within each round of the iteration
    calls the function bisector for each side combination.
    
    Param dir_path: (str) The object directory path.
    Param obj_path: (str) The object path.
    Param orig_coll: (collection) Original object.
    Param edit_coll: (collection) Edited segments.
    Param rem_coll: (collection) Remaining segment.
    Param rem_obj: (object) The remainder object.
    Param obj_name: (str) The object name.
    Param n_segs: (int) The number of segments.
    Param axis: (str) The axis along which the object is cut.
    Param avg_dim: (float) The average dimensional value of object seg.
    Param dims: (float list) The dimensional values of object segs.
    Param intersects: (float list) The object cut locations.
    Param step: (float) The adjustation to the cut location.
    Param em: (float) The error margin.
    Param dim_type: (str) The dimension (sa or v) to be calculated.
    Return dims: (float list) The dimensional values of object segs.
    Return intersects: (float list) The new object cut locations.
    """

    # Go through the list of divisions to obtain the segments
    for i in range(n_segs-1):

        # The checkers keep track of under- and overshooting
        checkers = [False, False]

        # Perform first bisecting along the initial intersect
        edit_obj = bisector(edit_coll, rem_obj, axis, "outer", intersects[i],
                            dim_type)

        # Calculate the dimensional value (SA or V)
        dims[i] = dim_value(dim_type)

        # Find the new dimensions and intersects (unless initial run)
        if avg_dim != 0:
            dims[i], intersects[i] = find_intersect(dir_path, edit_coll,
                                                    rem_obj, axis, avg_dim,
                                                    dims[i], checkers,
                                                    intersects[i], em, step,
                                                    dim_type, i)

        # Get the remainder
        edit_obj = bisector(edit_coll, rem_obj, axis, "inner", intersects[i],
                            dim_type)

        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Save the remainder segment into the rem_coll
        rem_obj = edit_obj.copy()
        rem_obj.data = rem_obj.data.copy()
        rem_coll.objects.link(rem_obj)

    # Calculate the dimensional value (SA or V)
    dims[i+1] = dim_value(dim_type)

    # Clear the edit_coll
    for obj in edit_coll.objects:
        bpy.data.objects.remove(obj)

    # Copy object from orig_coll to rem_coll
    obj_copy = orig_coll.objects[0].copy()
    obj_copy.data = obj_copy.data.copy()
    rem_coll.objects.link(obj_copy)
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj_copy
    obj_copy.select_set(state=True)

    return dims, intersects

#..........................................................................................


def slice_mesh_main(obj_path, n_segs, axis, em, dim_type):
    """ 
    Slices the mesh into segments equal in surface area or volume.

    Param obj_path: (str) The object path.
    Param n_segs: (int) The number of segments.
    Param axis: (str) The axis x/y/z along which the object is cut.
    Param em: (float) The error margin.
    Param dim_type: (str) The dimension (sa or v) to be calculated.
    """

    t_start = time.time()

    # Reduce em for the calculation by 10
    em_orig = em
    em = em / 10

    # Get the object directory
    dir_path = os.path.dirname(obj_path)

    # Get the object name
    obj_name = Path(obj_path).stem

    # Select and position the object
    obj = select_obj()
    position_obj()

    # Get the object rotation
    euler_r = obj.rotation_euler

    # Save the original object into a new collection
    orig_coll = bpy.data.collections.new('Original')
    bpy.context.scene.collection.children.link(orig_coll)
    orig_coll.objects.link(obj)
    bpy.data.collections[0].objects.unlink(obj)

    # Create a remainder collection to save segments temporarily
    rem_coll = bpy.data.collections.new('Remainder')
    bpy.context.scene.collection.children.link(rem_coll)

    # Copy the object from orig_coll to rem_coll
    rem_obj = orig_coll.objects[0].copy()
    rem_obj.data = rem_obj.data.copy()
    rem_coll.objects.link(rem_obj)
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = rem_obj
    rem_obj.select_set(state=True)

    # Get the dimension of the object
    dim_obj = dim_value(dim_type)

    # Get the object length along one axis
    obj_len = "rem_obj.dimensions." + axis
    obj_len = eval(obj_len)

    # Get the initial length of one segment
    seg_len = obj_len/n_segs

    # Create a list for the initial intersect values
    intersects = []

    # Define the intersects for object at origin
    for seg in range(1, n_segs):
        intersect = float((obj_len/2)-(seg_len)*seg)
        intersects.append(intersect)

    # Create a list to store the dimensions of the segments
    dims = []
    for dim in range(n_segs):
        dim = 0
        dims.append(dim)

    # Set the average dimension to 0 for the initial sectioning
    avg_dim = 0

    # Set the initial step size tenth of the segment length
    step = seg_len/10

    # Create a collection for editing
    edit_coll = bpy.data.collections.new('Edit')
    bpy.context.scene.collection.children.link(edit_coll)

    # Find the initial dimensions based on the initial intersects
    dims, intersects = sectioner(dir_path, obj_path, orig_coll, edit_coll,
                                 rem_coll, rem_obj, obj_name, n_segs, axis,
                                 avg_dim, dims, intersects, step, em,
                                 dim_type)

    # Calculate the average dimension
    avg_dim = statistics.mean(dims)

    # Define new dimensions and intersects
    dims, intersects = sectioner(dir_path, obj_path, orig_coll, edit_coll,
                                 rem_coll, rem_obj, obj_name, n_segs, axis,
                                 avg_dim, dims, intersects, step, em,
                                 dim_type)

    rem_obj = rem_coll.objects[0]

    tag = ("segments_" + dim_type + "_" + str(n_segs) + "_" + axis + "_euler_"
           + str(round(euler_r[0], 3)) + "_" + str(round(euler_r[1], 3)) + "_"
           + str(round(euler_r[2], 3)) + "_em_" + str(round(em_orig, 5)))

    # Get each segment
    obj_seg = 1

    for intersect in intersects:

        # Get the segment
        edit_obj = bisector(edit_coll, rem_obj, axis, "outer", intersect,
                            dim_type)
        bpy.ops.object.mode_set(mode='OBJECT')

        # Triangulate the segment
        bpy.ops.object.modifier_add(type='TRIANGULATE')
        bpy.ops.object.modifier_apply(modifier="Triangulate")

        # Export the segment into the segment folder
        seg_dir_path, seg_path = export_item(dir_path, obj_name, obj_seg,
                                             tag, ".obj")

        # Get the remainder
        edit_obj = bisector(edit_coll, rem_obj, axis, "inner", intersect,
                            dim_type)
        bpy.ops.object.mode_set(mode='OBJECT')

        # Save the remainder into rem_coll
        rem_obj = edit_obj.copy()
        rem_obj.data = rem_obj.data.copy()
        rem_coll.objects.link(rem_obj)
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = rem_obj
        rem_obj.select_set(state=True)

        obj_seg += 1


    # Export the final segment into the segment folder
    seg_dir_path, seg_path = export_item(dir_path, obj_name, obj_seg, tag,
                                         ".obj")
    t_end = time.time()
    t_elapsed = t_end - t_start

    # Convert the dimensions into strings and join together
    dim_str_list = [str(dims) for dims in dims]
    dim_str = ' '.join(dim_str_list)

    # Save parameters and the elapsed time into an output file
    output_values = np.array([obj_name, str(t_elapsed), dim_type,
                              str(n_segs), axis, str(euler_r[0]),
                              str(euler_r[1]), str(euler_r[2]),
                              str(round(em_orig, 5)), dim_str])
    labels = np.array(["Shape name", "Elapsed time (s)", "Dimension",
                       "Segments", "Axis", "Euler rotation (X)",
                       "Euler rotation (Y)", "Euler rotation (Z)",
                       "Error margin", "Segment dimensions"])
    final_output = False
    save_output(dir_path, output_values, labels, final_output,
                obj_name + "_slicemesh")

    clear_scene()

    # Remove all subcollections
    remove_collections(bpy.data.collections)

    # Create a subcollection
    seg_collection_name = str(obj_name) + "_segments"
    seg_collection = bpy.data.collections.new(seg_collection_name)
    bpy.context.scene.collection.children.link(seg_collection)

    # Import the object segments
    for file in os.listdir(seg_dir_path):
        filename = os.fsdecode(file)
        if filename.endswith(".obj"):

            # Get the segment path and import it
            seg_path = os.path.join(seg_dir_path, filename)
            bpy.ops.import_scene.obj(filepath=seg_path)

            # Define the segment name
            seg_name = Path(seg_path).stem

            # Add the segment to the correct subcollection
            obj = bpy.context.scene.objects[0]
            seg_collection.objects.link(obj)
            bpy.context.scene.collection.objects.unlink(obj)

            # Rename the segment
            obj.name = seg_name

    # Select and activate only the first segment
    bpy.ops.object.select_all(action='DESELECT')
    obj = bpy.data.collections[0].objects[1]
    bpy.context.view_layer.objects.active = obj
    obj.select_set(state=True)

    # Maximize the 3d view in order to display the object correctly
    max_3d_view()
