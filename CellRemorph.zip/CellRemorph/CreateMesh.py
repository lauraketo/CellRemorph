# -*- coding: utf-8 -*-
"""
Description: Transforms a point cloud into a mesh.

Blender version: 3.4.1

@author: Laura Keto
"""

import os
import os.path
from operator import itemgetter
from os import path

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Vector

from .General import (clear_scene, create_obj, dim_value, export_item,
                      init_scene, max_3d_view, obj_import, position_obj,
                      remove_collections, save_output, select_obj)


def get_coords(sel):
    """Returns the point cloud (obj) coordinates (float tuple list)."""

    # Get the point cloud coordinates
    coord_list = [(sel.matrix_world @ v.co) for v in sel.data.vertices]

    # Save the coordinates as floating value tuples into a list
    coords = []
    for v in coord_list:
        coord = (float(v[0]), float(v[1]), float(v[2]))
        coords.append(coord)

    return coords


def fill_edgeloop(el_coords):
    """Fills up an edge loop with a face."""

    # Get the active mesh
    me = bpy.context.object.data

    # Create a bmesh representation of the mesh
    bm = bmesh.new()
    bm.from_mesh(me)

    # Switch temporarily to edit mode to deselect everything
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action = 'DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')

    # Select only the vertices that belong to the edge loop
    for vert in bm.verts:
        for coord in el_coords:
            if (vert.co.x == coord[0] and vert.co.y == coord[1] and
                   vert.co.z == coord[2]):
                bpy.context.object.data.vertices[vert.index].select = True

    bpy.ops.object.mode_set(mode='EDIT')

    # Select all the edges connecting the edge loop vertices
    for edge in bm.edges:
        if edge.verts[0].select and edge.verts[1].select:
            edge.select = True

    # Fill the edge loop with a face
    bpy.ops.mesh.fill()


def ccw(A,B,C):
    """Returns true if A, B, and C are in a counterclockwise order."""
    return (C[1]-A[1]) * (B[0]-A[0]) > (B[1]-A[1]) * (C[0]-A[0])


def check_line_intersect(A, B, C, D):
    """Returns true if lines AB and CD intersect."""
    return ccw(A,C,D) != ccw(B,C,D) and ccw(A,B,C) != ccw(A,B,D)


def convert_mesh(coords):
    """
    Converts a point cloud segment consisting of stacked loops of 
    points into a mesh. The loops are saved first as separate meshes,
    then converted into convex hulls, and finally transformed into
    edge loops. The edge loops are bridged together to form a complete
    mesh. Before the cut surface is covered, the surface area of the
    shape is calculated. The volume is calculated after covering.

    Param coords: (float tuple list) The point cloud coordinates.
    Return sa: (float) The mesh surface area.
    Return v: (float) The mesh volume.
    """

    # Sort the point cloud coordinates into a nested list of loops
    loops = []
    loop = []
    for i in range(0, len(coords)-1):
        if coords[i][2] == coords[i+1][2]:
            loop.append(coords[i])
        else:
            loops.append(loop)
            loop = []
    loops.append(loop)

    # Create a collection for the coordinate point loops
    pt_coll = bpy.data.collections.new('pt_coll')
    bpy.context.scene.collection.children.link(pt_coll)

    # Create a collection for the convex hulls
    ch_coll = bpy.data.collections.new('ch_coll')
    bpy.context.scene.collection.children.link(ch_coll)

    # Create a collection for the edge loops
    el_coll = bpy.data.collections.new('el_coll')
    bpy.context.scene.collection.children.link(el_coll)

    # Transform each loop to object and from object to convex hull
    i = 0
    for loop in loops:

        # Create an object from the loop points, save into pt_coll
        obj = create_obj(loop)
        pt_coll.objects.link(obj)
        obj = pt_coll.objects[i]

        # Get the object mesh
        me = obj.data

        # Create a bmesh representation of the mesh
        bm = bmesh.new()
        bm.from_mesh(me)

        # If the shape has too few vertices, terminate code
        if len(bm.verts) < 3:

            # Remove all the collections and the objects within them
            remove_collections([pt_coll, ch_coll, el_coll])

            # Set both volume and surface area to zero
            v = sa = 0
            return v, sa

        # Make a copy of the object
        copy = obj.copy()

        # Make a new mesh
        me = bpy.data.meshes.new("%s convexhull" % me.name)

        # Create a new convex hull bmesh
        ch = bmesh.ops.convex_hull(bm, input=bm.verts)
        bmesh.ops.convex_hull(bm, input=bm.verts)

        # Convert the convex hull bmesh to mesh
        bm.to_mesh(me)
        copy.name = "%s (convex hull)" % obj.name
        copy.data = me

        # Save the convex hull mesh into the ch_coll
        ch_coll.objects.link(copy)

        i += 1

    # Transform the convex hulls into edge loops
    for ch in range(0, len(ch_coll.objects)):

        # Get the object coordinates
        obj = ch_coll.objects[ch]
        ch_coords = get_coords(obj)

        # Get the edges
        edges = []
        for edge in obj.data.edges:
            edges.append([edge.vertices[0], edge.vertices[1]])

        # Organize the edges
        for i in range(0, len(edges)):
            if edges[i][0] > edges[i][1]:
                edge1 = edges[i][1]
                edge2 = edges[i][0]
                edges[i][0] = edge1
                edges[i][1] = edge2
        edges = sorted(edges, key=itemgetter(0))

        # Find intersecting edges
        intersects = []
        for i in range(0, len(edges)):
            edge1 = edges[i]
            line_intersects = []
            for j in range(0, len(edges)):
                edge2 = edges[j]
                if edge1 != edge2:
                    A = ch_coords[edge1[0]]
                    B = ch_coords[edge1[1]]
                    C = ch_coords[edge2[0]]
                    D = ch_coords[edge2[1]]
                    if A != C and A != D and B != C and B != D:
                        line_intersect = check_line_intersect(A,B,C,D)
                        line_intersects.append(line_intersect)
            if any(line_intersects):
                line_intersect = True
            else:
                line_intersect = False
            intersects.append(line_intersect)

        # Remove the intersecting edges
        edges = [x for x, y in zip(edges, intersects) if y == False]

        # Create a list for vertices with extra edges
        vert_extra = []

        # Go through the vertices in the loop
        for i in range(0, len(ch_coords)+1):
            edges_at_vert = 0

            # Find how many edges are connected to one vertex
            for edge in edges:

                # Check the connectivity of both tips of one edge
                if edge[0] == i:
                    edges_at_vert += 1
                if edge[1] == i:
                    edges_at_vert += 1

            # More than 2 edges at a vertex indicate redundant line
            if edges_at_vert > 2:
                vert_extra.append(i)

        # Find and remove the redundant edge
        for edge in edges:

            # The number of vertices with extra edges must be over 2
            if len(vert_extra) < 2:
                break

            # Edge connected to two verts with extra edges is redundant
            if edge[0] == vert_extra[0] and edge[1] == vert_extra[1]:
                edges.remove(edge)
            if edge[0] == vert_extra[1] and edge[1] == vert_extra[0]:
                edges.remove(edge)

        # Create an object consisting of the vertices and edges
        obj = create_obj(ch_coords, edges)

        # Save the object into the el_coll
        el_coll.objects.link(obj)

    # Get the coordinates of the first and last edge loops
    first_el_coords = get_coords(el_coll.objects[0])
    last_el_coords = get_coords(el_coll.objects[-1])

    # Select all the edge loops in the el_coll and join them together
    for obj in el_coll.objects:
        obj.select_set(True)
        bpy.ops.object.join()

    # Switch temporarily to edit mode to bridge the edge loops together
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.bridge_edge_loops()
    bpy.ops.object.mode_set(mode='OBJECT')

    # Fill up the first edge loop to calculate the surface area
    fill_edgeloop(first_el_coords)
    sa = dim_value("sa")

    # Fill up also the last edge loop to calculate the volume
    fill_edgeloop(last_el_coords)
    v = dim_value("v")
    
    # Triangulate the mesh
    bpy.ops.object.modifier_add(type='TRIANGULATE')
    bpy.ops.object.modifier_apply(modifier="Triangulate")

    # If the volume is negative or zero, shape incorrect
    if v <= 0:
        # Set both volume and surface area to zero
        v = sa = 0

    # Remove all the collections and the objects within them
    remove_collections([pt_coll, ch_coll, el_coll])

    return sa, v


def create_mesh(file_path):
    """
    Saves a selected segment of a mesh or point cloud into the given
    directory as a mesh or point cloud, respectively. Selection from a
    point cloud can be converted into a mesh and saved as a mesh as
    well. Initializes the original mesh or point cloud with the
    selected segment removed. If the selection is saved as a mesh, the
    volume and surface area are calculated and saved into an
    output-file.

    Param file_path: (str) Path to the file.
    """

    # Change to object mode and select the object
    bpy.ops.object.mode_set(mode='OBJECT')
    selection = bpy.context.active_object

    # Define path to the file directory and the name of the segment
    dir_path = os.path.dirname(file_path)
    file_name = os.path.basename(file_path)
    file_name = os.path.splitext(file_name)[0]

    # Get the point location coordinates
    coords = get_coords(selection)

    # Convert it to mesh and calculate SA and V
    sa, v = convert_mesh(coords)

    # If unsuccesful, initialize the scene and shape, and terminate
    if sa == v == 0:

        # Select the separated segment
        obj = bpy.data.collections[0].objects[0]
        bpy.context.view_layer.objects.active = obj
        bpy.data.collections[0].objects[0].select_set(state=True)

        # Delete the possible edges and faces
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.delete(type='EDGE_FACE')
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.view_layer.objects.active = obj
        bpy.data.collections[0].objects[0].select_set(state=True)

        end_msg = "Selected shape unsuitable for conversion."
        return end_msg

    # Export the segment
    #export_item(dir_path, file_name, 1, "mesh", ".obj")

    # Define a path to the output-file
    output_path = os.path.join(dir_path, file_name + "_mesh_output.dat")

    # Define a number for the segment based on the output-file
    if not path.exists(output_path):
        # Numbering starts from one if no output-file exist
        sel_number = 1
    else:
        # Consecutive segments are numbered based on the info on output
        sel_number = sum(1 for line in open(output_path))

    # Rename the segment
    obj = bpy.data.collections[0].objects[-1]
    obj.name = "Selection_" + str(sel_number)

    # Save the parameters into the existing or a new output-file
    final_output = False
    output_values = np.array([str(sel_number), str(v), str(sa)])
    labels = np.array(["Selection", "Volume", "Surface Area"])
    save_output(dir_path, output_values, labels, final_output, file_name +
                "_mesh")

    # Initialize the scene
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = bpy.data.collections[0].objects[0]
    bpy.data.collections[0].objects[0].select_set(state=True)
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='SELECT')

    # Maximize the 3d view in order to display the object correctly
    max_3d_view()

    end_msg = "Selection successful"
    return end_msg

