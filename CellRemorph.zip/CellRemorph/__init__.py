bl_info = {
    "name": "CellRemorph",
    "author": "Laura Keto",
    "version": (1, 0, 0),
    "blender": (3, 4, 1),
    "location":"View3d",
    "description":"Toolkit for transforming and slicing 3D cell structures",
    "warning":"",
    "wiki_url":"",
    "category":"Mesh",
}

import os
import os.path

import bpy
from bpy.props import (BoolProperty, BoolVectorProperty, FloatProperty,
                       FloatVectorProperty, IntProperty, IntVectorProperty,
                       PointerProperty, StringProperty)
from bpy.types import Menu, Operator, Panel, PropertyGroup, Scene
from bpy_extras.io_utils import ExportHelper, ImportHelper

from .General import *
from .CreateMesh import *
from .CreatePtCloud import *
from .Selector import *
from .Slicer import *


class MyProperties(PropertyGroup):

    file_path_1 : StringProperty(
        name = "",
        description = "Path to File",
        default = "",
        maxlen = 1024,
        subtype = 'FILE_PATH')

    file_path_2a : StringProperty(
        name = "",
        description = "Path to File",
        default = "",
        maxlen = 1024,
        subtype = 'FILE_PATH')

    file_path_2 : StringProperty(
        name = "",
        description = "Path to File",
        default = "",
        maxlen = 1024,
        subtype = 'FILE_PATH')

    file_path_3 : StringProperty(
        name = "",
        description = "Path to File",
        default = "",
        maxlen = 1024,
        subtype = 'FILE_PATH')

    res : IntProperty(
        name = "",
        default = 100,
        description = "Grid resolution",
        soft_min = 0
        )

    n_tiers : IntVectorProperty(
        name = "",
        description = "Keep every nth tier of points in x/y/z direction",
        default = (1, 1, 1),
        soft_min = 1
        )

    axes : BoolVectorProperty(
        name = "Axis",
        description = "Axis of division",
        subtype="XYZ"
        )

    slice_by_SA : BoolProperty(
        name = "SA",
        description = "Slice by surface area"
        )

    slice_by_V : BoolProperty(
        name = "V",
        description = "Slice by volume"
        )
        
    n_segs : IntProperty(
        name = "",
        default = 2,
        description = "Number of segments along the chosen axis",
        soft_min = 2,
        soft_max = 100
        )

    em : FloatProperty(
        name = "",
        default = 0.001,
        description = "Error margin",
        soft_min = 0,
        soft_max = 100,
        step = 1,
        precision = 10
        )

    oct_depth : IntProperty(
        name = "",
        default = 7,
        description = ("Resolution of the octree; higher values give finer"
                       " details"),
        soft_min = 1,
        soft_max = 100
        )

    scale : FloatProperty(
        name = "",
        default = 0.9,
        description = ("The ratio of the largest dimension of the model over"
                       " the size of the grid"),
        soft_min = 0,
        soft_max = 0.99,
        precision = 10
        )

    subdiv_levels : IntProperty(
        name = "",
        default = 0,
        description = ("Number of subdivisions to perform"),
        soft_min = 0,
        soft_max = 6
        )

    meshmod_panel1_status : BoolProperty(
            default=False
        )

    meshmod_panel21_status : BoolProperty(
            default=False
        )

    meshmod_panel22_status : BoolProperty(
            default=False
        )

    meshmod_panel3_status : BoolProperty(
            default=False
        )

    transform_panel1_status : BoolProperty(
            default=False
        )

    transform_panel2_status : BoolProperty(
            default=False
        )


class CellRemorphPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'CellRemorph'


class PANEL_PT_CellRemorph(CellRemorphPanel, Panel):
    bl_idname = "PANEL_PT_CellRemorph"
    bl_label = "CellRemorph"

    def draw(self, context):
        layout = self.layout


class PANEL_PT_selector(CellRemorphPanel, Panel):
    bl_parent_id = "PANEL_PT_CellRemorph"
    bl_label = "1 Selector"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        meshmod_panel1_status = mytool.meshmod_panel1_status

        row = layout.row()
        row.label(text="Select Mesh / Point Cloud")
        row = layout.row()
        row.prop(mytool, "file_path_1", text="")
        row.operator("wm.myopi1")
        row = layout.row()

        row = layout.row()
        icon = 'DOWNARROW_HLT' if meshmod_panel1_status else 'RIGHTARROW'
        row.prop(mytool, 'meshmod_panel1_status', icon=icon, icon_only=True)
        row.label(text='Mesh modifications')

        if meshmod_panel1_status:
            box1 = layout.box()
            row = box1.row()
            row.label(text="Remesh")
            box = box1.box()
            row = box.row()
            row.label(text="Octree depth:")
            row.prop(mytool, "oct_depth")
            row = box.row()
            row.label(text="Scale:")
            row.prop(mytool, "scale")
            row = box.row()
            row.operator("wm.myopr1")
            row.operator("wm.myopra1")
            row = box1.row()
            row.label(text="Clean mesh")
            box = box1.box()
            row = box.row()
            row.operator("wm.myopc1")

        row = layout.row()
        row.operator("wm.myopsspc", icon='GROUP')


class PANEL_PT_transformer(CellRemorphPanel, Panel):
    bl_parent_id = "PANEL_PT_CellRemorph"
    bl_label = "2 Transformer"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        meshmod_panel21_status = mytool.meshmod_panel21_status
        meshmod_panel22_status = mytool.meshmod_panel22_status
        transform_panel1_status = mytool.transform_panel1_status
        transform_panel2_status = mytool.transform_panel2_status

        row = layout.row()
        icon = 'DOWNARROW_HLT' if transform_panel1_status else 'RIGHTARROW'
        row.prop(mytool, 'transform_panel1_status', icon=icon, icon_only=True)
        row.label(text='Point Cloud to Mesh')

        if transform_panel1_status:
            box1 = layout.box()
            row = box1.row()
            row.label(text="Select Point Cloud")
            row = box1.row()
            row.prop(mytool, "file_path_2a", text="")
            row.operator("wm.myopi2a")
            row = box1.row()

            row = box1.row()
            row.operator("wm.myopm", icon='MESH_DATA')

            row = box1.row()
            icon = 'DOWNARROW_HLT' if meshmod_panel21_status else 'RIGHTARROW'
            row.prop(mytool, 'meshmod_panel21_status', icon=icon, icon_only=True)
            row.label(text='Mesh modifications')

            if meshmod_panel21_status:
                box2 = box1.box()
                row = box2.row()
                row.label(text="Subdivision")
                box = box2.box()
                row = box.row()
                row.label(text="Levels:")
                row.prop(mytool, "subdiv_levels")
                row = box.row()
                row.operator("wm.myopsub")
                row.operator("wm.myopsuba")

            row = box1.row()
            row.operator("wm.myopscmpc", icon='GROUP')

        row = layout.row()
        icon = 'DOWNARROW_HLT' if transform_panel2_status else 'RIGHTARROW'
        row.prop(mytool, 'transform_panel2_status', icon=icon, icon_only=True)
        row.label(text='Mesh to Point Cloud')

        if transform_panel2_status:
            box1 = layout.box()
            row = box1.row()
            row.label(text="Select Mesh")
            row = box1.row()
            row.prop(mytool, "file_path_2", text="")
            row.operator("wm.myopi2")
            row = box1.row()

            row = box1.row()
            icon = 'DOWNARROW_HLT' if meshmod_panel22_status else 'RIGHTARROW'
            row.prop(mytool, 'meshmod_panel22_status', icon=icon, icon_only=True)
            row.label(text='Mesh modifications')

            if meshmod_panel22_status:
                box2 = box1.box()
                row = box2.row()
                row.label(text="Remesh")
                box = box2.box()
                row = box.row()
                row.label(text="Octree depth:")
                row.prop(mytool, "oct_depth")
                row = box.row()
                row.label(text="Scale:")
                row.prop(mytool, "scale")
                row = box.row()
                row.operator("wm.myopr2")
                row.operator("wm.myopra2")
                row = box2.row()
                row.label(text="Clean mesh")
                box = box2.box()
                row = box.row()
                row.operator("wm.myopc2")

            row = box1.row()
            row.label(text="Grid Resolution:")
            row.prop(mytool, "res")
            row = box1.row()
            row.label(text="Keep:")
            row.prop(mytool, "n_tiers")
            row = box1.row()
            row.operator("wm.myoppc", icon='OUTLINER_OB_POINTCLOUD')


class PANEL_PT_slicer(CellRemorphPanel, Panel):
    bl_parent_id = "PANEL_PT_CellRemorph"
    bl_label = "3 Slicer"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.my_tool
        meshmod_panel3_status = mytool.meshmod_panel3_status

        row = layout.row()
        row.label(text="Select Mesh")
        row = layout.row()
        row.prop(mytool, "file_path_3", text="")
        row.operator("wm.myopi3")
        row = layout.row()

        row = layout.row()
        icon = 'DOWNARROW_HLT' if meshmod_panel3_status else 'RIGHTARROW'
        row.prop(mytool, 'meshmod_panel3_status', icon=icon, icon_only=True)
        row.label(text='Mesh modifications')

        if meshmod_panel3_status:
            box1 = layout.box()
            row = box1.row()
            row.label(text="Remesh")
            box = box1.box()
            row = box.row()
            row.label(text="Octree depth:")
            row.prop(mytool, "oct_depth")
            row = box.row()
            row.label(text="Scale:")
            row.prop(mytool, "scale")
            row = box.row()
            row.operator("wm.myopr2")
            row.operator("wm.myopra2")
            row = box1.row()
            row.label(text="Clean mesh")
            box = box1.box()
            row = box.row()
            row.operator("wm.myopc2")

        row = layout.row()
        row.label(text="Slice by:")
        row.prop(mytool, "slice_by_SA")
        row.prop(mytool, "slice_by_V")
        row = layout.row()
        row.label(text="Segments:")
        row.prop(mytool, "n_segs")
        row = layout.row()
        row.prop(mytool, "axes")
        row = layout.row()
        row.label(text="Error Margin:")
        row.prop(mytool, "em")
        row = layout.row()
        row.operator("wm.myopsm", icon='OUTLINER_OB_SURFACE')


class WM_OT_myOpI1(Operator):
    """Import mesh or point cloud"""
    bl_label = "Import"
    bl_idname = "wm.myopi1"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_1 = mytool.file_path_1

        if file_path_1 == "":
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Select the mesh or point cloud.")
        elif (not file_path_1.endswith('.obj') and
              not file_path_1.endswith('.dat')):
            self.report({'ERROR_INVALID_INPUT'}, 
                        "The selected object must be in obj- or dat-format.")
        else:
            if not obj_import(file_path_1, "edit"):
                self.report({'ERROR_INVALID_INPUT'}, ("The point cloud file"
                            " must consist of rows that each have three"
                            " numerical coordinate values."))

        return {'FINISHED'}


class WM_OT_myOpI2a(Operator):
    """Import point cloud"""
    bl_label = "Import"
    bl_idname = "wm.myopi2a"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_2a = mytool.file_path_2a

        if file_path_2a == "":
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Select the point cloud.")
        elif not file_path_2a.endswith('.dat'):
            self.report({'ERROR_INVALID_INPUT'}, 
                        "The selected object must be in dat-format.")
        else:
            if not obj_import(file_path_2a, "edit"):
                self.report({'ERROR_INVALID_INPUT'}, ("The point cloud file"
                            " must consist of rows that each have three"
                            " numerical coordinate values."))

        return {'FINISHED'}


class WM_OT_myOpI2(Operator):
    """Import mesh"""
    bl_label = "Import"
    bl_idname = "wm.myopi2"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_2 = mytool.file_path_2

        if file_path_2 == "":
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Select the mesh.")
        elif not file_path_2.endswith('.obj'):
            self.report({'ERROR_INVALID_INPUT'}, 
                        "The selected object must be in obj-format.")
        else:
            obj_import(file_path_2)

        return {'FINISHED'}


class WM_OT_myOpI3(Operator):
    """Import mesh"""
    bl_label = "Import"
    bl_idname = "wm.myopi3"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_3 = mytool.file_path_3

        if file_path_3 == "":
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Select the mesh.")
        elif not file_path_3.endswith('.obj'):
            self.report({'ERROR_INVALID_INPUT'}, 
                        "The selected object must be in obj-format.")
        else:
            obj_import(file_path_3)

        return {'FINISHED'}


class WM_OT_myOpC1(Operator):
    """Remove disconnected segments from the mesh"""
    bl_label = "Clean Mesh"
    bl_idname = "wm.myopc1"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_1 = mytool.file_path_1

        if file_path_1.endswith('.dat'):
            self.report({'ERROR_INVALID_INPUT'}, "Only mesh can be cleaned.")
        else:
            clean_obj()

        return {'FINISHED'}


class WM_OT_myOpC2(Operator):
    """Remove disconnected segments from the mesh"""
    bl_label = "Clean Mesh"
    bl_idname = "wm.myopc2"

    def execute(self, context):
        clean_obj()

        return {'FINISHED'}


class WM_OT_myOpR1(Operator):
    """Remesh"""
    bl_label = "Remesh"
    bl_idname = "wm.myopr1"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        oct_depth = mytool.oct_depth
        scale = mytool.scale
        file_path_1 = mytool.file_path_1

        if file_path_1.endswith('.dat'):
            self.report({'ERROR_INVALID_INPUT'}, "Only meshes can be remeshed.")
        else:
            remesher(oct_depth, scale)

        return {'FINISHED'}

class WM_OT_myOpR2(Operator):
    """Remesh"""
    bl_label = "Remesh"
    bl_idname = "wm.myopr2"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        oct_depth = mytool.oct_depth
        scale = mytool.scale
        file_path_1 = mytool.file_path_1

        remesher(oct_depth, scale)

        return {'FINISHED'}


class WM_OT_myOpRA1(Operator):
    """Apply remesh"""
    bl_label = "Apply"
    bl_idname = "wm.myopra1"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_1 = mytool.file_path_1

        if file_path_1.endswith('.dat'):
            self.report({'ERROR_INVALID_INPUT'}, "Only meshes can be remeshed.")
        else:
            # Save the original mode and go to object mode
            original_mode = bpy.context.object.mode
            bpy.ops.object.mode_set(mode='OBJECT')

            # Apply the remesh
            bpy.ops.object.modifier_apply(modifier="Remesh")

            # Switch to the original more
            bpy.ops.object.mode_set(mode=original_mode)

            if bpy.context.object.mode == "EDIT":
                bpy.ops.mesh.select_all(action='SELECT')

        return {'FINISHED'}


class WM_OT_myOpRA2(Operator):
    """Apply remesh"""
    bl_label = "Apply"
    bl_idname = "wm.myopra2"

    def execute(self, context):

        bpy.ops.object.modifier_apply(modifier="Remesh")

        return {'FINISHED'}

class WM_OT_myOpSUB(Operator):
    """Subdivide"""
    bl_label = "Subdivide"
    bl_idname = "wm.myopsub"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        subdiv_levels = mytool.subdiv_levels
        active_obj = bpy.context.active_object

        if subdiv_levels == 0:
            active_obj.modifiers.clear()
        else:
            if len(active_obj.modifiers) == 0:
                subdiv = bpy.ops.object.modifier_add(type='SUBSURF')
            else:
                subdiv = active_obj.modifiers[0]
                subdiv.levels = subdiv_levels

        return {'FINISHED'}

class WM_OT_myOpSUBA(Operator):
    """Apply subdivision"""
    bl_label = "Apply"
    bl_idname = "wm.myopsuba"

    def execute(self, context):

        bpy.ops.object.modifier_apply(modifier="Subdivision")

        return {'FINISHED'}


class WM_OT_myOpSCM(Operator):
    """Save the created mesh"""
    bl_label = "Save Mesh"
    bl_idname = "wm.myopscmpc"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_2a = mytool.file_path_2a

        dir_path_2a = os.path.dirname(file_path_2a)
        file_name_2a = os.path.basename(file_path_2a)
        file_name_2a = os.path.splitext(file_name_2a)[0]
        export_item(dir_path_2a, file_name_2a, 1, "mesh", ".obj")

        return {'FINISHED'}


class WM_OT_myOpSS(Operator):
    """Save the selection"""
    bl_label = "Save Selection"
    bl_idname = "wm.myopsspc"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_1 = mytool.file_path_1

        end_msg = save_selection(file_path_1)
        if end_msg != "Selection successful":
            self.report({'ERROR_INVALID_INPUT'}, end_msg)

        return {'FINISHED'}


class WM_OT_myOpM(Operator):
    """Create Mesh"""
    bl_label = "Create Mesh"
    bl_idname = "wm.myopm"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_2a = mytool.file_path_2a

        objects = bpy.context.scene.objects.keys()
        obj_name = Path(file_path_2a).stem

        if file_path_2a == "":
            self.report({'ERROR_INVALID_INPUT'},
                        "Select the point cloud.")
        elif not file_path_2a.endswith('.dat'):
            self.report({'ERROR_INVALID_INPUT'}, 
                        "The selected point cloud must be in dat-format.")
        elif len(objects) != 1:
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Import the point cloud.")
        elif objects[0] != obj_name:
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Import the point cloud.")
        else:
            end_msg = create_mesh(file_path_2a)
            if end_msg != "Selection successful":
                self.report({'ERROR_INVALID_INPUT'}, end_msg)

        return {'FINISHED'}


class WM_OT_myOpPC(Operator):
    """Create Point Cloud"""
    bl_label = "Create Point Cloud"
    bl_idname = "wm.myoppc"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_2 = mytool.file_path_2
        res = mytool.res
        n_tiers = mytool.n_tiers

        objects = bpy.context.scene.objects.keys()
        obj_name = Path(file_path_2).stem

        if file_path_2 == "":
            self.report({'ERROR_INVALID_INPUT'},
                        "Select the mesh.")
        elif not file_path_2.endswith('.obj'):
            self.report({'ERROR_INVALID_INPUT'}, 
                        "The selected mesh must be in obj-format.")
        elif len(objects) != 1:
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Import the mesh.")
        elif objects[0] != obj_name:
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Import the mesh.")
        else:
            ptcloud_main(file_path_2, res, n_tiers)

        return {'FINISHED'}


class WM_OT_myOpSM(Operator):
    """Open the Slice Mesh dialog box"""
    bl_label = "Slice Mesh"
    bl_idname = "wm.myopsm"

    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        file_path_3 = mytool.file_path_3
        axes = mytool.axes
        n_segs  = mytool.n_segs
        slice_by_SA = mytool.slice_by_SA
        slice_by_V = mytool.slice_by_V
        em = mytool.em

        if slice_by_SA:
            dim_type = "sa"
        if slice_by_V:
            dim_type = "v"

        selected_axes = 0
        for axis in axes:
            if axis:
                selected_axes += 1

        if axes[0]:
            axis = "x"
        elif axes[1]:
            axis = "y"
        elif axes[2]:
            axis = "z"

        objects = bpy.context.scene.objects.keys()
        obj_name = Path(file_path_3).stem

        if file_path_3 == "":
            self.report({'ERROR_INVALID_INPUT'},
                        "Select the mesh.")
        elif not file_path_3.endswith('.obj'):
            self.report({'ERROR_INVALID_INPUT'}, 
                        "The selected mesh must be in obj-format.")
        elif not (slice_by_SA != slice_by_V):
            self.report({'ERROR_INVALID_INPUT'},
                        "Choose to slice either by surface area or volume.")
        elif any(axes) == False:
            self.report({'ERROR_INVALID_INPUT'}, "Choose one of the axes.")
        elif selected_axes > 1:
            self.report({'ERROR_INVALID_INPUT'}, "Choose only one of the axes.")
        elif len(objects) != 1:
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Import the mesh.")
        elif objects[0] != obj_name:
            self.report({'ERROR_INVALID_INPUT'}, 
                        "Import the mesh.")
        else:
            slice_mesh_main(file_path_3, n_segs, axis, em, dim_type)

        return {'FINISHED'}


classes = (
    MyProperties,
    PANEL_PT_CellRemorph,
    PANEL_PT_selector,
    PANEL_PT_transformer,
    PANEL_PT_slicer,
    WM_OT_myOpI1,
    WM_OT_myOpI2a,
    WM_OT_myOpI2,
    WM_OT_myOpI3,
    WM_OT_myOpC1,
    WM_OT_myOpC2,
    WM_OT_myOpR1,
    WM_OT_myOpR2,
    WM_OT_myOpRA1,
    WM_OT_myOpRA2,
    WM_OT_myOpSUB,
    WM_OT_myOpSUBA,
    WM_OT_myOpSS,
    WM_OT_myOpSCM,
    WM_OT_myOpM,
    WM_OT_myOpPC,
    WM_OT_myOpSM,
)


def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    Scene.my_tool = PointerProperty(type=MyProperties)


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del Scene.my_tool


if __name__ == "__main__":
    register()

