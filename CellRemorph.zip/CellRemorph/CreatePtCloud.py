# -*- coding: utf-8 -*-
"""
Description: Slices an object into segments in order to create a grid
particle system that is denser than the default maximum concentration
in Blender. The grid particle system captures the detailed morphology 
of the object into a uniform point cloud whose density can be adjusted
in x, y, and/or z direction. The locations of the points are saved into
a dat-file.

Blender version: 3.4.1

@author: Laura Keto
"""

import math
import os
import os.path
import time
from itertools import product
from os import path
from pathlib import Path

import bpy
import numpy as np

from .General import (max_3d_view, position_obj, remove_collections,
                      save_output, select_obj)


def get_factors(res):
    """
    Defines factors for obtaining the wanted grid resolution for an
    object with the minimum number of divisions needed.

    Param res: (int) Wanted grid resolution.
    Return dim_factor: (float) Factor for scaling the frame.
    Return res_calc: (int) Grid resolution for calculation.
    Return div_factor: (int) The number by which the obj is divided.
    """

    # Initialize the factors
    div_factor = 0
    dim_factor = 1
    res_calc = res

    # The maximum value for resolution in Blender
    res_max = 250

    # Update the factors if the wanted resolution exceeds the maximum
    if res > res_max:
        dim_factor = 1/(res_calc/250)
        res_calc = 250
        while dim_factor < 1:
            div_factor += 1
            dim_factor = dim_factor*2

    return div_factor, dim_factor, res_calc


def frame_obj(obj, frame, dim_factor=1):
    """
    Conjoins an object with a three dimensional frame. The frame is
    either a fitted rectangle or a cube with the dimensions of the
    longest object dimension times the scaling factor.

    Param obj: (obj) The object.
    Param frame: (str) Frame type (cube/fitted rectangle).
    Param dim_factor: (float) Factor for scaling a cubical frame.
    """

    # Position the object in the origin
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')

    # Change the context temporarily to position the cursor in 3D view
    previous_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'

    # Create either a cubical or fitted bounding box for the object
    if frame == "cube":

        # Position the object to the cursor
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        # Position the cursor the center
        bpy.ops.view3d.snap_cursor_to_center()

        # Return to the previous context
        bpy.context.area.type = previous_context

        # Add a cube for the bounding box
        bpy.ops.mesh.primitive_cube_add()
        b_box = bpy.context.active_object

        # Get the longest object dimension times the scaling factor
        dim_max = max(obj.dimensions)
        dim = dim_max*dim_factor

        # Scale the cube to the obtained dimension
        b_box.dimensions = [dim, dim, dim]

    elif frame == "fit":

        # Position the object to the cursor
        bpy.ops.view3d.snap_cursor_to_selected()

        # Return to the previous context
        bpy.context.area.type = previous_context

        # Add a cube for the bounding box
        bpy.ops.mesh.primitive_cube_add()
        b_box = bpy.context.active_object

        # Scale the cube to the object dimensions
        b_box.dimensions = obj.dimensions

    # Make the bounding box location and rotation same as the object's
    b_box.location = obj.location
    b_box.rotation_euler = obj.rotation_euler

    # Remove bounding box faces so that only the frame remains
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.delete(type='ONLY_FACE')

    # Conjoin the frame and the object
    bpy.ops.object.mode_set(mode='OBJECT')
    for obj in bpy.context.view_layer.active_layer_collection.collection.all_objects:
        obj.select_set(True)
    bpy.ops.object.join()


def bisector(axis, side):
    """
    Bisects the object into two parts and preserves one of the sides.
    The object is cut along x/y/z axis at the bounding box center.

    Param axis: (int) The axis by which the object is cut.
    Param side: (str) The side of the object to be preserved.
    """

    # Change to edit mode and select the whole object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')

    # Change the context temporarily to position the cursor
    previous_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'

    # Position the pivot point to the object bounding box center
    scene = bpy.context.scene
    scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'

    # Position the cursor to the pivot point
    bpy.ops.view3d.snap_cursor_to_selected()

    # Return to the previous context
    bpy.context.area.type = previous_context

    # Bisect the object along one of the axes
    if axis == 0:

        # Get the x coordinate of the bounding box center
        intersect = bpy.context.scene.cursor.location.x

        # Bisect the object along the intersect, save one side
        if side == "outer":
            bpy.ops.mesh.bisect(plane_co=(intersect, 0, 0),
                                plane_no=(1, 0, 0), clear_inner=True,
                                clear_outer=False)
        elif side == "inner":
            bpy.ops.mesh.bisect(plane_co=(intersect, 0, 0),
                                plane_no=(1, 0, 0), clear_inner=False,
                                clear_outer=True)
    elif axis == 1:

        # Get the y coordinate of the bounding box center
        intersect = bpy.context.scene.cursor.location.y

        # Bisect the object along the intersect, save one side
        if side == "outer":
            bpy.ops.mesh.bisect(plane_co=(0, intersect, 0),
                                plane_no=(0, 1, 0), clear_inner=True,
                                clear_outer=False)
        elif side == "inner":
            bpy.ops.mesh.bisect(plane_co=(0, intersect, 0),
                                plane_no=(0, 1, 0), clear_inner=False,
                                clear_outer=True)
    elif axis == 2:

        # Get the z coordinate of the bounding box center
        intersect = bpy.context.scene.cursor.location.z

        # Bisect the object along the intersect, save one side
        if side == "outer":
            bpy.ops.mesh.bisect(plane_co=(0, 0, intersect),
                                plane_no=(0, 0, 1), clear_inner=True,
                                clear_outer=False)
        elif side == "inner":
            bpy.ops.mesh.bisect(plane_co=(0, 0, intersect),
                                plane_no=(0, 0, 1), clear_inner=False,
                                clear_outer=True)

    # Select the obtained side of the object
    bpy.ops.mesh.select_all(action='SELECT')


def get_side_combs(div_factor):
    """
    Creates a list of side combinations based on the division number.

    Param div_factor: (int) The number by which the obj is divided.
    Return side_combs: (str list list) The side combinations.
    """
    subdiv_factor = div_factor*3
    side_combs = list(product(["outer", "inner"], repeat = subdiv_factor))

    return side_combs


def sectioner(side_comb, div_factor):
    """
    Iterates through a list of divisions to be performed for each
    coordinate axis. Within each round of the iteration calls the
    function bisector for each side combination and frames the obtained
    object within a fitted rectangle.

    Param div_factor: (int) The number by which the obj is divided.
    Param side_comb: (str list) The side combination to be executed.
    """
    axis = 0
    i = 0
    for _ in range(3):
        for _ in range(div_factor):
            side = side_comb[i]
            bisector(axis, side)
            bpy.ops.object.mode_set(mode='OBJECT')
            obj = select_obj()
            frame_obj(obj, "fit")
            i += 1
        axis += 1
        if axis == 3:
            axis = 0


def particle_saver(ptcloud_path, obj_name, res_calc):
    """
    Creates a grid particle system for the object segment currently
    active in the workspace. Saves the point locations of the particle
    system into a dat-file (for the first segment creates a new file,
    for consecutive segments appends to the same file).

    Param ptcloud_path: (str) The point cloud path.
    Param obj_name: (str) The object name.
    Param res_calc: (int) Grid resolution to be used in calculation.
    """

    # Select the active object
    active_obj = bpy.context.active_object
    active_obj.select_set(state=True)

    # Create a new grid particle system for the active object
    active_obj.modifiers.new("grid_partsys", type='PARTICLE_SYSTEM')
    grid_partsys = active_obj.particle_systems[0]

    # Define the particle system settings
    settings = grid_partsys.settings
    settings.physics_type = 'NO'
    settings.frame_start = 1
    settings.frame_end = 1
    settings.lifetime = 250
    settings.distribution = 'GRID'
    settings.particle_size = 0.01
    settings.grid_resolution = res_calc
    settings.show_unborn = True
    settings.use_dead = True
    bpy.ops.object.duplicates_make_real()

    # Get the reference to the particle system
    dg = bpy.context.evaluated_depsgraph_get()
    ob = bpy.context.object.evaluated_get(dg)
    ps = ob.particle_systems.active

    # Get the point locations of the particle system
    point_locs = [p.location for p in ps.particles]

    # Save the point locations to a new file or append to an old file
    if path.exists(ptcloud_path) == False:
        np.savetxt(ptcloud_path, point_locs, delimiter=" ", fmt='%s')
    else:
        f=open(ptcloud_path, 'ab')
        np.savetxt(f, point_locs, delimiter=" ", fmt='%s')
        f.close()


def sparsify(ptcloud_path, c_axis, n_tier):
    """
    Sparsifies a grid point cloud along one axis by removing every tier
    of points except every nth that is retained. Rounds the point
    coordinates in order to group points whose location only sligthly
    varies onto the same tiers. 

    Param ptcloud_path: (str) The point cloud path.
    Param c_axis: (int) The axis by which the ptcloud is sparsified.
    Param n_tier: (int) Every nth point cloud tier retained.
    """

    # Read the point cloud coordinates into a list
    all_coords = []
    with open(ptcloud_path, 'r') as read_obj:
        for line in read_obj:
            coords = line.split()
            all_coords.append(coords)

    # Transform the coordinates into floating point numbers
    all_coords = [list(map(float, coords)) for coords in all_coords]

    # Round the coordinates
    all_coords = ([[round(coord, 6) for coord in coords] 
                  for coords in all_coords])

    # Organize the list of points by the axis that is sparsified
    def custom_key(coords):
        return coords[c_axis]
    all_coords.sort(key=custom_key)

    # Set the minimum value required for the difference between points
    min_diff = 0.0001

    # Check the difference between neighboring points
    for c in range(0, len(all_coords)-1):

        # If the difference less than min_diff, set 2nd point to 1st
        if (all_coords[c+1][c_axis] != all_coords[c][c_axis]
            and -min_diff < (all_coords[c+1][c_axis]
            - all_coords[c][c_axis]) < min_diff):
            all_coords[c+1][c_axis] = all_coords[c][c_axis]

    # Create lists for the lines and coordinates to be deleted
    tiers_del = []
    coords_del = []

    # Create a list for the coordinates to be retained
    coords_retain = []

    # Find the lines where points misaligned and tiers to be deleted
    n1 = 0
    n2 = n_tier-1
    for coords in all_coords:
        if n1 < n2:
            tiers_del.append(all_coords.index(coords))
            coords_del.append(coords)
        if (len(coords_del) > 1 and coords[c_axis] != coords_del[-2][c_axis]):
            n1 += 1
        if n1 == n2:
            coords_retain.append(coords)
            coords_del = []
        if (len(coords_retain) > 1 and coords[c_axis]
            != coords_retain[-2][c_axis]):
            n1 = 0
            coords_retain = []

    # Delete the tiers
    i = 0
    for tier in tiers_del:
        del all_coords[tier-i]
        i += 1

    # Create a list for the tiers to be deleted
    tiers_del = []

    # Add to the list of tiers to be deleted those with only one point
    for i in range(0, len(all_coords)-2):
        if (all_coords[i+1][c_axis] != all_coords[i][c_axis]
            and all_coords[i+1][c_axis] != all_coords[i+2][c_axis]):
            tiers_del.append(i+1)

    # Delete the tiers
    i = 0
    for tier in tiers_del:
        del all_coords[tier-i]
        i += 1

    # Remove the old point locations
    if os.path.exists(ptcloud_path):
        os.remove(ptcloud_path)

    # Save the new point locations
    np.savetxt(ptcloud_path, all_coords, delimiter=" ", fmt='%s')

#..........................................................................................


def ptcloud_main(obj_path, res, n_tiers):
    """
    Converts a mesh (obj) into a point cloud (dat). Displays the mesh
    and the point cloud created for it in 3D object format (ply) in
    Blender. Saves an output file with the parameters and elapsed
    times into the mesh directory. Creates a subdirectory to save the
    point cloud in botrh  dat- and ply-formats.

    Param obj_path: (str) The object path.
    Param res: (int) Wanted grid resolution.
    Param n_tiers: (int list) Every nth point cloud tier retained.
    """
    
    # Define factors for scaling the frame
    div_factor, dim_factor, res_calc = get_factors(res)

    t_start = time.time()

    # Get the object directory
    dir_path = os.path.dirname(obj_path)

    # Get the object name
    obj_name = Path(obj_path).stem

    # Select the object
    obj = select_obj()

    # Get the object rotation
    euler_r = obj.rotation_euler.copy()

    # Apply the object's rotation to its data
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

    # Position the object
    position_obj()

    # Create a list of side combinations based on div_factor
    side_combs = get_side_combs(div_factor)

    # Define the path to the point cloud directory
    res_dir = obj_name + "_pointclouds"
    res_dir_path = os.path.join(dir_path, res_dir)

    # Create the directory (if it has not been already created)
    if not os.path.exists(res_dir_path):
        os.mkdir(res_dir_path)

    # Define the path to the point cloud
    ptcloud_file = (obj_name + "_pointcloud_res" + "_" + str(res) +
                    "_keep_" + str(n_tiers[0]) + str(n_tiers[1]) +
                    str(n_tiers[2]) + "_euler_" + str(round(euler_r[0], 3)) +
                    "_" + str(round(euler_r[1], 3)) + "_" + 
                    str(round(euler_r[2], 3)) + ".dat")
    ptcloud_path = os.path.join(res_dir_path, ptcloud_file)

    # Rename the original collection
    orig_coll = bpy.data.collections[0]
    orig_coll.name = str(obj_name) + "_pointcloud"

    # Create edit collection to save segments temporarily
    edit_coll = bpy.data.collections.new('Edit')
    bpy.context.scene.collection.children.link(edit_coll)

    # Check if point cloud exist for the obj, if not, create it
    if not path.exists(ptcloud_path):

        # Go through each side_comb
        for side_comb in side_combs:

            # Clear any objects from edit_coll
            for obj in edit_coll.objects:
                bpy.data.objects.remove(obj)

            # Copy object from orig_coll to edit_coll
            obj = orig_coll.objects[0].copy()
            obj.data = obj.data.copy()
            edit_coll.objects.link(obj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = obj
            obj.select_set(state=True)

            # Make the edit collection active
            edit_lc = bpy.context.view_layer.layer_collection.children[-1]
            bpy.context.view_layer.active_layer_collection = edit_lc

            # Create a cubical frame scaled by dim_factor
            frame_obj(obj, "cube", dim_factor)

            # Check if the mesh needs to be divided
            if div_factor != 0:
                sectioner(side_comb, div_factor)

            # Create a particle system and save into a file
            particle_saver(ptcloud_path, obj_name, res_calc)

    t_end = time.time()
    t_elapsed = t_end - t_start

    # Save parameters and the elapsed time into an output file
    output_values = np.array([obj_name, str(t_elapsed), str(res),
                             str(n_tiers[0]), str(n_tiers[1]), 
                             str(n_tiers[2]), str(euler_r[0]),
                             str(euler_r[1]), str(euler_r[2])])
    labels = np.array(["Shape name", "Elapsed time (s)", "Resolution",
                       "Retain X", "Retain Y", "Retain Z",
                       "Euler rotation (X)", "Euler rotation (Y)",
                       "Euler rotation (Z)"])
    final_output = False
    save_output(dir_path, output_values, labels, final_output, obj_name +
                "_createptcloud")

    # Define the ply-path from the point cloud path
    pre, ext = os.path.splitext(ptcloud_path)
    ply_path = pre + ".ply"

    # Check if the ply-file is already created
    if not path.exists(ply_path):

        # Check if along any axis less than each tier is to be retained
        for c_axis in range(0,3):
            if n_tiers[c_axis] != 1:
                sparsify(ptcloud_path, c_axis, n_tiers[c_axis])

        # Transform the point couds into ply-format
        num_lines = sum(1 for line in open(ptcloud_path))
        vertex_number = 'element vertex ' + str(num_lines)
        ply_lines = ['ply', 'format ascii 1.0',  'comment VCGLIB generated',
                     vertex_number, 'property float x', 'property float y',
                     'property float z', 'element face 0', 'property list \
                     uchar int vertex_indices', 'end_header']
        ply_file = ptcloud_path + '.bak'
        with open(ptcloud_path, 'r') as r_obj, open(ply_file, 'w') as w_obj:
            for line in ply_lines:
                w_obj.write(line + '\n')
            for line in r_obj:
                w_obj.write(line)
        os.rename(ply_file, ply_path)

    # Make the original collection active
    lc = bpy.context.view_layer.layer_collection.children[orig_coll.name]
    bpy.context.view_layer.active_layer_collection = lc

    # Import the ply-formatted point cloud
    bpy.ops.import_mesh.ply(filepath=ply_path)

    # Remove the edit collection
    remove_collections([edit_coll])

    # Deselect all objects
    for obj in bpy.context.selected_objects:
        obj.select_set(state=False)

    # Select and activate only the first point cloud
    obj = bpy.data.collections[0].objects[1]
    bpy.context.view_layer.objects.active = obj
    obj.select_set(state=True)

    # Maximize the 3d view in order to display the object correctly
    max_3d_view()
